# UVM Basics

I am using this repository to practice UVM coding.
The idea is to use a very simple design (APB memory in this case) and focus on the UVM side.

I've tried to comment as much of the code as possible.
I will keep adding whatever I think is interesting and what I might need a reference of in future.

Submit a pull request or open an issue if you want to see more.
