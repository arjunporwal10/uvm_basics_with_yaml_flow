
#!/usr/bin/env python3
import os, sys, json

def sv_header():
    return "// Auto-generated scenario_config_pkg.sv\npackage scenario_config_pkg;\n  import avry_yaml_types_pkg::*;\n  import stimulus_auto_builder_pkg::*;\n  function automatic avry_scenario_cfg get_scenario_by_name(string name);\n    avry_scenario_cfg cfg = avry_scenario_cfg::type_id::create(name);\n    if (0) ;\n"

def sv_footer():
    return "    return cfg;\n  endfunction\nendpackage\n"

def sv_id(x): return x

def emit_actions(lst, prefix):
    lines=[]
    # declare
    for i,_ in enumerate(lst):
        lines.append(f"    stimulus_action_t {prefix}{i};")
    # build
    for i,a in enumerate(lst):
        at = a["action_type"]
        data = a.get("action_data", {})
        if at=="RESET":
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_reset();")
        elif at=="SELF_CHECK":
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_self_check();")
        elif at=="TRAFFIC":
            n = int(data.get("num_packets", 8)); base = int(data.get("addr_base",0)); pat = int(data.get("data_pattern",0))
            dirn = data.get("direction","write").lower()
            dirc = "DIR_WRITE" if dirn.startswith("w") else "DIR_READ"
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_traffic({dirc}, {n}, {base}, 32'h{pat:08X});")
        elif at=="PARALLEL_GROUP":
            subs = data.get("parallel_actions",[])
            subp = f"{prefix}{i}_"
            lines += emit_actions(subs, subp)
            names = ", ".join([f"{subp}{j}" for j in range(len(subs))])
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_parallel('{{{names}}});")
        elif at=="SERIAL_GROUP":
            subs = data.get("serial_actions",[])
            subp = f"{prefix}{i}_"
            lines += emit_actions(subs, subp)
            names = ", ".join([f"{subp}{j}" for j in range(len(subs))])
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_serial('{{{names}}});")
        else:
            # unknown -> default to RESET
            lines.append(f"    {prefix}{i} = stimulus_auto_builder::build_reset(); // unknown {at}")
    return lines

def emit_case(scen):
    nm = scen.get("scenario_name","unnamed")
    lines = [f'  else if (name == "{nm}") begin',
             f'    cfg.scenario_name = "{nm}";']
    if "timeout_value" in scen:
        lines.append(f'    cfg.timeout_value = {int(scen["timeout_value"])};')
    # actions
    acts = scen.get("action_list",[])
    if acts:
        lines += emit_actions(acts, "a_")
        lines.append("    cfg.action_list.delete();")
        for i in range(len(acts)):
            lines.append(f"    cfg.action_list.push_back(a_{i});")
    else:
        lines.append("    cfg.action_list.delete();")
    lines.append("  end")
    return "\n".join(lines)

def main(yaml_dir, out_sv):
    # Load all *.yaml (very limited parser to avoid PyYAML)
    scenarios=[]
    for fn in os.listdir(yaml_dir):
        if not fn.endswith(".yaml"): continue
        with open(os.path.join(yaml_dir, fn)) as f:
            txt=f.read()
        # crude parse for scenario_name and action_list in JSON-like python dict
        try:
            # expect file to be JSON as fallback
            data=json.loads(txt)
        except:
            # super-minimal YAML: translate to JSON-ish
            txt2 = txt.replace(": true", ": 1").replace(": false", ": 0")
            txt2 = txt2.replace("'", '"')
            # arrays of maps remain similar; this will work for our provided examples if valid JSON.
            try:
                data=json.loads(txt2)
            except Exception as e:
                print(f"[WARN] Could not parse {fn}: {e}")
                continue
        if "scenario_name" not in data:
            print(f"[SKIP] {fn}: missing scenario_name")
            continue
        scenarios.append(data)

    with open(out_sv,"w") as f:
        f.write(sv_header())
        for sc in scenarios:
            f.write(emit_case(sc)+"\n")
        f.write(sv_footer())
    print(f"[OK] wrote {out_sv} with {len(scenarios)} scenarios")

if __name__=="__main__":
    if len(sys.argv)!=3:
        print("Usage: python3 yaml_flow/tools/yaml2sv.py <yaml_dir> <out_sv>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
